import tkinter as tk
from tkinter import simpledialog, messagebox
from tkinter import filedialog
from PIL import Image, ImageTk
import pandas as pd

class TransactionLookupApp:
    def __init__(self, root):
        """
        Initialize the TransactionLookupApp.

        Parameters:
            root (tk.Tk): The root window of the application.
        """
        self.root = root
        root.title("Transaction Lookup")
        root.iconbitmap(r'C:\Users\Owen\Desktop\SDEV140\MillsOwenM08FinalProject\photos\favicon.ico')
        root.geometry("1000x700")

        # Load images for light mode, dark mode, and the switches
        self.light_mode_img = ImageTk.PhotoImage(Image.open("C:\\Users\\Owen\\Desktop\\SDEV140\\MillsOwenM08FinalProject\\photos\\lightspartanlogo.png"))
        self.dark_mode_img = ImageTk.PhotoImage(Image.open("C:\\Users\\Owen\\Desktop\\SDEV140\\MillsOwenM08FinalProject\\photos\\nightspartanlogo.png"))
        self.switch_light_img = ImageTk.PhotoImage(Image.open("C:\\Users\\Owen\\Desktop\\SDEV140\\MillsOwenM08FinalProject\\photos\\lightswitch.png"))
        self.switch_dark_img = ImageTk.PhotoImage(Image.open("C:\\Users\\Owen\\Desktop\\SDEV140\\MillsOwenM08FinalProject\\photos\\nightswitch.png"))

        # Initial image
        self.current_image = self.light_mode_img

        # Image at the top of the application
        self.top_image_label = tk.Label(root, image=self.current_image, borderwidth=0, highlightthickness=0, text="Spartan Logo")
        self.top_image_label.pack()

        # Light switch and dark switch buttons
        self.toggle_mode_button = tk.Button(root, image=self.switch_light_img, command=self.toggle_mode, bd=0, bg="#333333", borderwidth=0, highlightthickness=0, text="Light Mode Switch")
        self.toggle_mode_button.place(x=10, y=10)

        # Widget for entering a name
        self.address_label = tk.Label(root, text="Enter your name for your earned cryptocurrency information:", font=("Arial", 12), bg="#f0f0f0", fg="black")
        self.address_label.pack(pady=10)

        # Set the design for the application
        self.address_entry = tk.Entry(root, font=("Arial", 12), bg="white", fg="black")  
        self.address_entry.pack(pady=10)

        # Button to look up transactions
        self.lookup_button = tk.Button(root, text="Lookup Transactions", font=("Arial", 12), command=self.lookup_transactions, relief=tk.RAISED, bg="#1a4fc9", fg="#fff")
        self.lookup_button.pack(pady=20)

        # Exit button
        self.exit_button = tk.Button(root, text="Exit", font=("Arial", 12), command=root.destroy, relief=tk.RAISED, bg="#1a4fc9", fg="#fff")
        self.exit_button.pack(pady=20)

        # Styling
        self.light_mode = tk.BooleanVar(value=True)
        self.set_light_mode_colors()

    def set_light_mode_colors(self):
        """
        Set default light mode colors for the application.
        """
        # Set default light mode colors
        self.label_background_color = "#f0f0f0"  # Background color for labels
        self.entry_background_color = "white"  # Background color for entry widget
        self.text_color = "black"  # Text color
        self.button_color = "#1a4fc9"  # Background color for buttons
        self.button_text_color = "#fff"  # Text color for buttons

        # Set initial background color
        self.root.configure(bg="#f0f0f0")

        # Set background color for toggle button
        self.toggle_mode_button.configure(bg="#f0f0f0")

    def set_dark_mode_colors(self):
        """
        Set dark mode colors for the application.
        """
        # Set dark mode colors
        self.label_background_color = "#333333"  # Background color for labels
        self.entry_background_color = "#333333"  # Background color for entry widget
        self.text_color = "white"  # Text color
        self.button_color = "#1a4fc9"  # Background color for buttons
        self.button_text_color = "#fff"  # Text color for buttons

        # Set dark mode background color
        self.root.configure(bg="#333333")

        # Set background color for toggle button
        self.toggle_mode_button.configure(bg="#333333")

    def toggle_mode(self):
        """
        Toggle between light mode and dark mode.
        """
        if self.light_mode.get():
            self.set_dark_mode_colors()
            self.toggle_mode_button.configure(image=self.switch_dark_img)
            self.current_image = self.dark_mode_img
        else:
            self.set_light_mode_colors()
            self.toggle_mode_button.configure(image=self.switch_light_img)
            self.current_image = self.light_mode_img

        # Update spartan logo
        self.top_image_label.configure(image=self.current_image)

        # Toggle button colors
        self.lookup_button.configure(bg=self.button_color, fg=self.button_text_color)
        self.exit_button.configure(bg=self.button_color, fg=self.button_text_color)

        # Toggle entry colors
        self.address_entry.configure(bg=self.entry_background_color, fg=self.text_color)

        # Toggle label colors
        self.address_label.configure(bg=self.label_background_color, fg=self.text_color)

        # Invert the light_mode variable
        self.light_mode.set(not self.light_mode.get())

    def lookup_transactions(self):
        """
        Lookup transactions based on the entered name and display the results.
        """
        try:
            # Get the name from the user
            entered_address = self.address_entry.get()

            # Check if the name is provided
            if not entered_address:
                messagebox.showerror("Error", "Please enter a name.")
                return

            # Ask the user for the CSV file
            file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])

            # Check if the user canceled the input
            if not file_path:
                return

            # Read the CSV file
            df = pd.read_csv(file_path)

            # Check if the name is valid and in the CSV file
            if entered_address not in df['Receiver'].values:
                messagebox.showerror("Error", "Please enter a valid name (make sure both the first and last name are both capital with no spaces at the end).")
                return

            # Get transactions from the entered name
            transactions = df[df['Receiver'] == entered_address]

            # Display the transactions with Date, Amount, Token, and Token USD Value
            info_message = f"Transactions for: {entered_address}\n\n"
            for _, transaction in transactions.iterrows():
                info_message += f"Date: {transaction['Time']}, Amount: {transaction['Token Amount']}, Token: {transaction['Token']}, Token USD Value: {transaction['Token USD Value']}\n"
            messagebox.showinfo("Transactions", info_message)

        except FileNotFoundError:
            messagebox.showerror("Error", "File not found. Please enter a valid file path.")

        except Exception as e:
            # Display an error if there was a problem
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
            
if __name__ == "__main__":
    root = tk.Tk()
    app = TransactionLookupApp(root)
    root.mainloop()
